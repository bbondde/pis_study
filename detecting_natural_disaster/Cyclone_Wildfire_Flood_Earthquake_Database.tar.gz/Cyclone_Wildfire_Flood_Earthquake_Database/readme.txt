ABOUT DATABASE
1. Images are collected from Google, it may be noisy and different resolutions, therefore, preprocessing is recommended.
2. Please remove irrelevant image if necessary
3. Number of image samples in each class is different which may result biased model. Select images according to your application.
4. I tried to remove duplicate images, still there may be some. Delete those images before training the model.
